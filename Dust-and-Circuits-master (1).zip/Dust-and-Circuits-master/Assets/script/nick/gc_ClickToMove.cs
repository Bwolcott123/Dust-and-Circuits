﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gc_ClickToMove : MonoBehaviour {

    public bool enabled = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
